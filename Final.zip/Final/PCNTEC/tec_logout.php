<?php
session_start();
unset($_SESSION['tec_data']);
header("location:../Bidder_Module/login.php");
 ?>
