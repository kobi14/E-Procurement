<?php
include('C:\xampp\htdocs\e-procurement\UI\connect.php');

if($_REQUEST['email']=="")
 {
 echo "Email is required";
}else{
  
}

 ?>
