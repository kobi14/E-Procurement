<?php
/**
 * Created by PhpStorm.
 * User: kobi.ktk
 * Date: 12/8/17
 * Time: 4:13 PM
 */

$conn = new PDO('mysql:host=localhost;dbname=procurement', 'root', '');


?>