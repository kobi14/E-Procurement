<?php
/**
 * Created by PhpStorm.
 * User: kobi.ktk
 * Date: 12/5/17
 * Time: 1:26 PM
 */
?>

<!doctype html>
<html lang="en">

<script type="text/javascript" src="../function/validation.js"></script>
<script>

    <div class="modal-body" style="max-height:450px; overflow:auto;">

        <div id="add-product-messages"></div>

        <div class="form-group">
            </div

</script>
<a href="postTender.php">

    <button type="submit" class="btn btn-success pull-right"  > OK </button></a>


</html>
