<?php
session_start();
unset($_SESSION['tec_data']);
header("location:login.php");
 ?>
